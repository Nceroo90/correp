<?php

$token = "5641503861:AAFDlXKR6UgVlpYVmrqmhftin2dBMU7l4bQ";
$chatid = "-867989421";
?>